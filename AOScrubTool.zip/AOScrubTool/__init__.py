def classFactory(iface):
    from .AOScrubTool import AOScrubToolPlugin
    return AOScrubToolPlugin(iface)
